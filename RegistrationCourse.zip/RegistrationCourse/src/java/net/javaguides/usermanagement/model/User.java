/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.javaguides.usermanagement.model;

/**
 *
 * @author Angelique
 */
public class User {
    protected int id;
    protected String name;
    protected String email;
    protected String mobile;
    protected String course;

    public User() {}

    public User(String name, String email,String mobile, String course) {
        super();
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.course = course;
    }

    public User(int id, String name, String email, String mobile, String course) {
        super();
        this.id = id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.course = course;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    public String getCourse() {
        return course;
    }
    public void setCourse(String course) {
        this.course = course;
    }
    
}
